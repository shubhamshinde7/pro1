<html>
    <head>
        <link href="editorCSS.css" rel="stylesheet" type="text/css"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    </head>
    <body style="margin-left:15%;margin-right: 15%;">
        <div class="nav">
            <h1 style="text-align: center;">MIT</h1>
            <hr>
            <a href="teacherHomePage.php" style="text-decoration: none;font-size: 30px;margin-left: 41%;">Home</a>
            <a href="teacherResults.php" style="text-decoration: none;text-align:  center; font-size: 30px;">Results</a>
            <a href="home.php" style="text-decoration: none;text-align: center; font-size: 30px;">Logout</a>
            <hr>
        </div>
        <?php
            $connection=new MongoClient();
            $db=$connection->project;
            $A_id=$_POST['A_id'];
            $A_title=$_POST['A_title'];
            $A_startDate=$_POST['A_startDate'];
            $A_endDate=$_POST['A_endDate'];
            $Result_Id="Result_".$A_id;
            //$Result_Id="Result_58a346214a181277083c9869";
            $collection=$db->$Result_Id;
            $query=$collection->find();
            $array=array();
            foreach ($query as $doc) {
                $array[]=$doc['code'];
            }
            $result=array();
            echo "count=".count($result);
            $result=plagirism($array);
            //print_r($result);
            $collection_student=$db->studentInfo;
            $cursor=$collection->find();
            echo "<h3>Title:</h3>";
            echo "<p>$A_title</p>";
            echo "<h3>Start Date:</h3>$A_startDate";
            echo "<h3>End Date:</h3>$A_endDate";
            echo "<h3>Download Result:</h3>";
            echo "<button id='btnExport' class='button'>Download Result</button>";
            echo "<h3>Results:</h3>";
            echo "<div id='table_wrapper'><table id='table'>";
            echo "<tr>";
            echo "<th>Roll No</th>";
            echo "<th>First Name</th>";
            echo "<th>Last Name</th>";
            echo "<th>Marks</th>";
            echo "<th>Plagirism</th>";
            echo "<th>Code</th>";
            echo "</tr>";
            $i=0;
            foreach ($cursor as $doc){
                $S_email=$doc['S_email'];
                $code=trim($doc['code']);
                $marks=$doc['marks'];
                $query=array('S_email'=>$S_email);
                $cursor1=$collection_student->find($query);
                foreach ($cursor1 as $doc_stu){
                    $S_rollNo=$doc_stu['S_rollNo'];
                    $S_firstName=$doc_stu['S_firstName'];
                    $S_lastName=$doc_stu['S_lastName'];
                }
                echo "<tr>";
                echo "<td>$S_rollNo</td>";
                echo "<td>$S_firstName</td>";
                echo "<td>$S_lastName</td>";
                echo "<td>$marks</td>";
                echo "<td>$result[$i]</td>";
                echo "<form action='viewCode.php' method='post'>";
                echo "<td><input type='submit' name='View Code' value='View Code' class='button'></td>";
                echo "<input type='hidden' name='S_firstName' value='$S_firstName'>";
                echo "<input type='hidden' name='S_lastName' value='$S_lastName'>";
                echo "<input type='hidden' name='S_rollNo' value='$S_rollNo'>";
                echo "<input type='hidden' name='code' value='$code'>";
                echo "<input type='hidden' name='marks' value='$marks'>";
                echo "<input type='hidden' name='Result_Id' value='$Result_Id'>";
                echo "<input type='hidden' name='S_email' value='$S_email'>";
                echo "</form>";
                echo "</tr>";
                $i=$i+1;
            }
            echo "</table></div>";
        ?>
        <script>
                $(document).ready(function() {
                $("#btnExport").click(function(e) {
                e.preventDefault();
                
                //getting data from our table
                var data_type = 'data:application/vnd.ms-excel';
                var table_div = document.getElementById('table_wrapper');
                var table_html = table_div.outerHTML.replace(/ /g, '%20');
                var a = document.createElement('a');
                a.href = data_type + ', ' + table_html;
                a.download = 'result' + '.xls';
                a.click();
                });
            });
    </script>
    <?php
    $Comment_Id="Comment_".$A_id;
    $coll_comment=$db->$Comment_Id;
    $query=$coll_comment->find();
    echo "<h3>Comments</h3>";
    echo "<table><tr><th>Name</th><th>Comment</th>";
    foreach ($query as $doc){
        echo "<tr>";
        echo "<td>".$doc['S_name']."</td>";
        echo "<td>".$doc['Comment']."</td>";
        echo "</tr>";
    }
    echo "</table>";
    ?>
    </body>
</html>

<?php
function plagirism($array)
{
    $result=array();
    for($i=0;$i<count($array);$i++){
        $j_max=0;
       // $token1=array();
        $token1= token($array[$i]);
        for($j=0;$j<count($array);$j++){
           // $token2=array();
            $token2= token($array[$j]);
            $jaccard=0;
            $same=0;
            $distinct=0;
            $flag=0;
            if($i!=$j){
                for($m=0;$m<count($token1)-3;$m=$m+4){
                    $flag=0;
                    for($n=0;$n<count($token2)-3;$n=$n+1){
                        //echo "<br/>same=$same distinct =$distinct ";
                        if(strcmp($token1[$m],$token2[$n])==0 && strcmp($token1[$m+1],$token2[$n+1])==0 && strcmp($token1[$m+2],$token2[$n+2])==0 && strcmp($token1[$m+3],$token2[$n+3])==0){
                            $same=$same+1;
                            $flag=1;
                            break;
                        }
                        if($flag==0){
                            $distinct=$distinct+1;
                        }
                    }
                }
                $jaccard=($same/ count($token2))*100;
                //echo "<br/>same=$same distinct=$distinct i=$i j=$j jaccard=$jaccard";
                if($jaccard>$j_max){
                    $j_max=$jaccard;
                }
            }
        }
       // echo "<br/>jaccard=".$j_max;
        $result[$i]=$j_max;
    }
    return $result;
}

function token($code)
{
    $string = $code;
    $keyword=array();
    $keywords=array();
    $ngram=array();
    $tok = strtok($string, " # < > , ( ) ; { } [ ] \" : \n \t & %");
    while ($tok !== false) {
        //echo "Word=$tok<br/>";
        $tok = strtok(" # < > , ( ) ; { } [ ] \" : \n \t & %");
        $keyword[]=$tok;
    }
    $keywords=array_map('trim',$keyword);
    $k=0;
    for($i=0;$i<count($keywords);$i++){
       
        if(strcmp($keywords[$i],"include") ==0 || strcmp($keywords[$i],"define") ==0 || strcmp($keywords[$i],"stdio.h") ==0 ||
                strcmp($keywords[$i],"assert.h") ==0 || strcmp($keywords[$i],"complex.h") ==0 || strcmp($keywords[$i],"ctype.h") ==0 ||
                strcmp($keywords[$i],"errorno.h") ==0 || strcmp($keywords[$i],"fenv.h") ==0 || strcmp($keywords[$i],"float.h") ==0 ||
                strcmp($keywords[$i],"string.h") ==0 || strcmp($keywords[$i],"math.h") ==0 || strcmp($keywords[$i],"stdlib.h") ==0 ||
                strcmp($keywords[$i],"time.h") ==0 || strcmp($keywords[$i],"stddef.h") ==0){
           $ngram[$k]=1;
           //echo "<br/>data=".$keywords[$i]."=1";
           $k++;
        }
        elseif (strcmp($keywords[$i],"auto") ==0 || strcmp($keywords[$i],"double") ==0 || strcmp($keywords[$i],"int") ==0 || strcmp($keywords[$i],"struct") ==0 ||
                strcmp($keywords[$i],"break") ==0 || strcmp($keywords[$i],"else") ==0 || strcmp($keywords[$i],"long") ==0 || strcmp($keywords[$i],"switch") ==0 ||
                strcmp($keywords[$i],"case") ==0 || strcmp($keywords[$i],"enum") ==0 || strcmp($keywords[$i],"typedef") ==0 || strcmp($keywords[$i],"register") ==0 ||
                strcmp($keywords[$i],"char") ==0 || strcmp($keywords[$i],"extern") ==0 || strcmp($keywords[$i],"return") ==0 || strcmp($keywords[$i],"union") ==0 ||
                strcmp($keywords[$i],"const") ==0 || strcmp($keywords[$i],"float") ==0 || strcmp($keywords[$i],"short") ==0 || strcmp($keywords[$i],"unsigned") ==0 ||
                strcmp($keywords[$i],"continue") ==0 || strcmp($keywords[$i],"for") ==0 || strcmp($keywords[$i],"signed") ==0 || strcmp($keywords[$i],"void") ==0 ||
                strcmp($keywords[$i],"default") ==0 || strcmp($keywords[$i],"goto") ==0 || strcmp($keywords[$i],"sizeof") ==0 || strcmp($keywords[$i],"volatile") ==0 ||
                strcmp($keywords[$i],"do") ==0 || strcmp($keywords[$i],"if") ==0 || strcmp($keywords[$i],"static") ==0 || strcmp($keywords[$i],"while") ==0) {
            $ngram[$k]=2;
            $k++;
            //echo "<br/>data=".$keywords[$i]."=2";
        }
        elseif (strcmp($keywords[$i],"+") ==0 || strcmp($keywords[$i],"-") ==0 || strcmp($keywords[$i],"*") ==0 || strcmp($keywords[$i],"/") ==0 || strcmp($keywords[$i],"%") ==0 ||
                strcmp($keywords[$i],"++") ==0 || strcmp($keywords[$i],"--") ==0 ||
                strcmp($keywords[$i],"=") ==0 || strcmp($keywords[$i],"+=") ==0 || strcmp($keywords[$i],"-=") ==0 || strcmp($keywords[$i],"*=") ==0 || strcmp($keywords[$i],"/=") ==0 ||
                strcmp($keywords[$i],"==") ==0 || strcmp($keywords[$i],">") ==0 || strcmp($keywords[$i],"<") ==0 || strcmp($keywords[$i],"<=") ==0 || strcmp($keywords[$i],">=") ==0 || strcmp($keywords[$i],"!=") ==0 ||
                strcmp($keywords[$i],"&&") ==0 || strcmp($keywords[$i],"||") ==0 || strcmp($keywords[$i],"!") ==0 ||
                strcmp($keywords[$i],"&") ==0 || strcmp($keywords[$i],"|") ==0 || strcmp($keywords[$i],"~") ==0 || strcmp($keywords[$i],"^") ==0 ||
                strcmp($keywords[$i],"<<") ==0 || strcmp($keywords[$i],">>") ==0 ||
                strcmp($keywords[$i],",") ==0 || strcmp($keywords[$i],"sizeof") ==0 || strcmp($keywords[$i],"?") ==0 || strcmp($keywords[$i],";") ==0) {
            $ngram[$k]=4;
            $k++;
            //echo "<br/>data=".$keywords[$i]."=4";
        }
        elseif (strcmp($keywords[$i],"0") ==0 || strcmp($keywords[$i],"1") ==0 || strcmp($keywords[$i],"2") ==0 || strcmp($keywords[$i],"3") ==0 ||
                strcmp($keywords[$i],"4") ==0 || strcmp($keywords[$i],"5") ==0 || strcmp($keywords[$i],"6") ==0 || strcmp($keywords[$i],"7") ==0 ||
                strcmp($keywords[$i],"8") ==0 || strcmp($keywords[$i],"9") ==0) {
            $ngram[$k]=5;
            $k++;
            //echo "<br/>data=".$keywords[$i]."=5";
        }
        elseif(strlen($keywords[$i])>0) {
            $ngram[$k]=3;
            $k++;
            //echo "<br/>data=".$keywords[$i]."=3";
        }
    }
    //print_r($ngram);
    return $ngram;
}

?>