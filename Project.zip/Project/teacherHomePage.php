<html>
    <head>
        <link href="editorCSS.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="margin-left:15%;margin-right: 15%;">
        <div class="nav">
            <h1 style="text-align: center;">MIT</h1>
            <hr>
            <a href="teacherHomePage.php" style="text-decoration: none;font-size: 30px;margin-left: 41%;">Home</a>
            <a href="teacherResults.php" style="text-decoration: none;text-align:  center; font-size: 30px;">Results</a>
            <a href="home.php" style="text-decoration: none;text-align: center; font-size: 30px;">Logout</a>
            <hr>
        </div>
        
        <table>
            <tr>
                <td><a href='newAssignment.php'><img src="Images/plus.png" alt=""/></a></td>
                <td><a href="viewResults.php"><img src="Images/result.png" alt=""/></a></td>
            </tr>
            <tr>
                <td>Create New Assignment</td>
                <td>View Assignment Results</td>
            </tr>
        </table>
    </body>
</html>