<?php
$connection=new MongoClient();
$db=$connection->project;
$A_id=$_POST['A_id'];
$S_email=$_POST['S_email'];
$Result_Id="Result_".$A_id;
$collection=$db->$Result_Id;
$query=array('S_email'=>$S_email);
$cursor=$collection->find($query);
foreach ($cursor as $doc){
    $code=$doc['code'];
    $marks=$doc['marks'];
    $feedback=$doc['feedback'];
}
?>
<html>
    <head>
        <link href="editorCSS.css" rel="stylesheet" type="text/css"/>
        <link href="CodeMirror/lib/codemirror.css" rel="stylesheet" type="text/css"/>
        <script src="CodeMirror/addon/edit/matchbrackets.js"></script>
        <link href="CodeMirror/addon/hint/show-hint.css" rel="stylesheet" type="text/css"/>
        <script src="CodeMirror/addon/hint/show-hint.js"></script>
        <script src="CodeMirror/mode/clike/clike.js"></script>
        <script src="CodeMirror/lib/codemirror.js"></script>
        <script src="jquery-3.1.1.min.js" type="text/javascript"></script>
    </head>
    <style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
    text-align: center;
}

li {
    float: left;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}

li.dropdown {
    display: inline-block;
}


</style>
    <body>
        <div class="nav">
            <h1 style="text-align: center;">MIT</h1>
            <ul>
                <li><a href="studentHomePage.php" style="float:right">Home</a></li>
                <li><a href="studentResults.php">Results</a></li>
                <li><a href="home.php">Logout</a></li>
            </ul>
        </div>
        <h3>Marks Obtained</h3>
        <?php echo $marks;?>
        <h3>Code</h3>
        <div id="editor_block">
            <textarea id="c-code"><?php echo $code;?></textarea>
            <script>
                var editor = CodeMirror.fromTextArea(document.getElementById("c-code"), {
                    lineNumbers: true,
                    matchBrackets: true,
                    mode: "text/x-csrc"
                });
            </script>
        </div>
        <h3>Feedback</h3>
        <?php echo $feedback;?>
    </body>
    </head>
</html>