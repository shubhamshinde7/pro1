<?php
$string = $code;
/* Use tab and newline as tokenizing characters as well  */
$tok = strtok($string, " #<>,();{}[]\":\n\t");
while ($tok !== false) {
    echo "Word=$tok<br />";
    $tok = strtok(" #<>,();{}[]\":\n\t");
}
$keywords = preg_split("/ #<>,();{}[]\":.\n\t/", $code);
print_r($keywords);

?>